$(document).ready(function(){
    /* --------------- 드롭다운 --------------- */
    $(".products_menu").hover(
        function(){                                
            $(".products_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".products_menu .dropdown").removeClass("over");
        },        
    );    
    $(".about_menu").hover(
        function(){                                
            $(".about_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".about_menu .dropdown").removeClass("over");
        }
    );  
    $(".support_menu").hover(
        function(){                                
            $(".support_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".support_menu .dropdown").removeClass("over");
        }
    );   
    $(".news_menu").hover(
        function(){                                
            $(".news_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".news_menu .dropdown").removeClass("over");
        }
    );  

    /* --------------- 드롭다운 글자색 hover --------------- */  
    $(".left_menu > li").hover(
        function(){        
            $(this).addClass("on")        
        },
        function(){        
            $(".left_menu > li").removeClass("on")        
        }
    );  

    $(".dropdown .products").hover(
        function(){        
            $(".products_menu").addClass("on")        
        },
        function(){        
            $(".products_menu").removeClass("on")        
        }
    );    
    $(".dropdown .about").hover(
        function(){        
            $(".about_menu a").addClass("on")        
        },
        function(){        
            $(".about_menu a").removeClass("on")        
        }
    );
    $(".dropdown .support").hover(
        function(){        
            $(".support_menu a").addClass("on")        
        },
        function(){        
            $(".support_menu a").removeClass("on")        
        }
    );
    $(".dropdown .news").hover(
        function(){        
            $(".news_menu a").addClass("on")        
        },
        function(){        
            $(".news_menu a").removeClass("on")        
        }
    );

    /* --------------- 모바일 메뉴 --------------- */
    
    mobile_menu();
    
    function mobile_menu(){
        var $menu = null;
        var $left_gnb = null;

        function start(){
            init();
            init_event();
        }

        function init(){
            $menu = $('.menu');
            $left_gnb = $('.left_gnbWrap');
        }
        function init_event(){            
            $menu.click(function(e){
                e.preventDefault();
                $left_gnb.addClass('on');
            });            
          
            $('.close').click(function(e){
                e.preventDefault();    
                $left_gnb.removeClass('on');   
            }); 
            
            $(window).resize(function(){
                $left_gnb.removeClass('on');
            });
        }
        start(); 
    }

    var lnbUI = {
        clickE: function(target) {
            var $target = $(target);
            
            $(target).each(function() {
               if($(this).find('> ul').length > 0) {
                   return true;
               }
                $(this).addClass('noDepth');
            });
            
            $target.on('click', 'a', function() {
                var $this = $(this);
                var $depthTarget = $this.next();
                var $siblings = $this.parent().siblings(); 
                
                if($this.parent('li').hasClass('noDepth') === false) {
                    $('.lnb ul li ul li').removeClass('on');
                    
                    $this.parent().siblings().removeClass('on');                    
                    
                    $this.parent('li').siblings('li').find('ul').slideUp();
                    $this.parent('li').find('ul ul').slideUp();
                    
                    if($depthTarget.css('display') === 'none') {
                        $depthTarget.slideDown();
                        $this.parent('li').addClass('on');
                    } else {
                        $depthTarget.slideUp();
                        $this.parent('li').removeClass('on');
                    }
                } else {
                    //return false;
                 
                }
               // return false;
            });
        }
    }
    lnbUI.clickE('.lnb li')

    
    /* --------------- slider 영역 --------------- */  
    $(document).ready(function(){
    
        var $slides=$(".bxslider"); 
        var slider=$slides.bxSlider({
           pager: true,
           controls: false,
           infiniteLoop: true,
             auto: true
        });
    
        $('.banner_prev').on("click", function(){
            slider.goToPrevSlide();
         });
         $('.banner_next').on("click", function(){
            slider.goToNextSlide();
         });
    });
});
/* 탭 메뉴 */
$(function(){
  $('#content li').eq(0).click(function(){
      $('#content li').removeClass('on');
      $(this).addClass('on');
     
      $('.content2 > ul').css('display','none');
      $('.content2 > ul').eq(0).css('display','block');
      return false;
    });
  $('#content li').eq(1).click(function(){
    $('#content li').removeClass('on');
    $(this).addClass('on');
    $('.content2 > ul').eq(0).css('display','none');
    $('.content2 > ul').eq(1).css('display','block');
    $('.content2 > ul').eq(2).css('display','none');
    $('.content2 > ul').eq(3).css('display','none');
    $('.content2 > ul').eq(4).css('display','none');
    return false;
});
$('#content li').eq(2).click(function(){
    $('#content li').removeClass('on');
    $(this).addClass('on');
    $('.content2 > ul').eq(0).css('display','none');
    $('.content2 > ul').eq(1).css('display','none');
    $('.content2 > ul').eq(2).css('display','block');
    $('.content2 > ul').eq(3).css('display','none');
    $('.content2 > ul').eq(4).css('display','none');
    return false;
});
$('#content li').eq(3).click(function(){
    $('#content li').removeClass('on');
    $(this).addClass('on');
    $('.content2 > ul').eq(0).css('display','none');
    $('.content2 > ul').eq(1).css('display','none');
    $('.content2 > ul').eq(2).css('display','none');
    $('.content2 > ul').eq(3).css('display','block');
    $('.content2 > ul').eq(4).css('display','none');
    return false;
});
$('#content li').eq(4).click(function(){
    $('#content li').removeClass('on');
    $(this).addClass('on');
    $('.content2 > ul').eq(0).css('display','none');
    $('.content2 > ul').eq(1).css('display','none');
    $('.content2 > ul').eq(2).css('display','none');
    $('.content2 > ul').eq(3).css('display','none');
    $('.content2 > ul').eq(4).css('display','block');
    return false;
});
});

// 서비스센터,제품정보
$(function(){
    $('.sevice li').eq(0).hover(function(){
        $('.sevice li').eq(1).css("color", "#d13737");
    }, function(){
        $('.sevice li').eq(1).css("color", "#000");
    });
    $('.sevice li').eq(1).hover(function(){
        $('.sevice li').eq(1).css("color", "#d13737");
    }, function(){
        $('.sevice li').eq(1).css("color", "#000");
    });
    $('.sevice li').eq(2).hover(function(){
        $('.sevice li').eq(1).css("color", "#d13737");
    }, function(){
        $('.sevice li').eq(1).css("color", "#000");
    });
    $('.sevice li').eq(3).hover(function(){
        $('.sevice li').eq(4).css("color", "#d13737");
    }, function(){
        $('.sevice li').eq(4).css("color", "#000");
    });
    $('.sevice li').eq(4).hover(function(){
        $('.sevice li').eq(4).css("color", "#d13737");
    }, function(){
        $('.sevice li').eq(4).css("color", "#000");
    });
    $('.sevice li').eq(5).hover(function(){
        $('.sevice li').eq(4).css("color", "#d13737");
    }, function(){
        $('.sevice li').eq(4).css("color", "#000");
    });
});

$(function(){
    var $prevBtn=$("p.prev");
    var $nextBtn=$("p.next");
    var $slides=$(".imgslider");
 
 
    var slider=$slides.bxSlider({
       minSlides: 3,
       maxSlides: 3,
       slideWidth: 600,
       slideHeight: 520,
       slideMargin: 30,
       infiniteLoop: true,
       moveSlides: 1,
       pager: false,
       controls: false,
         auto: true,
         shrinkItems:true
    });
    
    $prevBtn.on("click", function(){
       slider.goToPrevSlide();
    });
    $nextBtn.on("click", function(){
       slider.goToNextSlide();
    });
});
