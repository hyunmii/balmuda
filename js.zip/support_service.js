$(function(){
    /* --------------- 드롭다운 --------------- */
    $(".products_menu").hover(
        function(){                                
            $(".products_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".products_menu .dropdown").removeClass("over");
        },        
    );    
    $(".about_menu").hover(
        function(){                                
            $(".about_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".about_menu .dropdown").removeClass("over");
        }
    );  
    $(".support_menu").hover(
        function(){                                
            $(".support_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".support_menu .dropdown").removeClass("over");
        }
    );   
    $(".news_menu").hover(
        function(){                                
            $(".news_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".news_menu .dropdown").removeClass("over");
        }
    );  
    
    /* --------------- 드롭다운 글자색 hover --------------- */  
    $(".left_menu > li").hover(
        function(){        
            $(this).addClass("on")        
        },
        function(){        
            $(".left_menu > li").removeClass("on")        
        }
    );  
    
    $(".dropdown .products").hover(
        function(){        
            $(".products_menu").addClass("on")        
        },
        function(){        
            $(".products_menu").removeClass("on")        
        }
    );    
    $(".dropdown .about").hover(
        function(){        
            $(".about_menu a").addClass("on")        
        },
        function(){        
            $(".about_menu a").removeClass("on")        
        }
    );
    $(".dropdown .support").hover(
        function(){        
            $(".support_menu a").addClass("on")        
        },
        function(){        
            $(".support_menu a").removeClass("on")        
        }
    );
    $(".dropdown .news").hover(
        function(){        
            $(".news_menu a").addClass("on")        
        },
        function(){        
            $(".news_menu a").removeClass("on")        
        }
    );

     /* --------------- 모바일 메뉴 --------------- */
    
     mobile_menu();
    
     function mobile_menu(){
         var $menu = null;
         var $left_gnb = null;
 
         function start(){
             init();
             init_event();
         }
 
         function init(){
             $menu = $('.menu');
             $left_gnb = $('.left_gnbWrap');
         }
         function init_event(){            
             $menu.click(function(e){
                 e.preventDefault();
                 $left_gnb.addClass('on');
             });            
           
             $('.close').click(function(e){
                 e.preventDefault();    
                 $left_gnb.removeClass('on');   
             }); 
             
             $(window).resize(function(){
                 $left_gnb.removeClass('on');
             });
         }
         start(); 
     }
 
     var lnbUI = {
         clickE: function(target) {
             var $target = $(target);
             
             $(target).each(function() {
                if($(this).find('> ul').length > 0) {
                    return true;
                }
                 $(this).addClass('noDepth');
             });
             
             $target.on('click', 'a', function() {
                 var $this = $(this);
                 var $depthTarget = $this.next();
                 var $siblings = $this.parent().siblings(); 
                 
                 if($this.parent('li').hasClass('noDepth') === false) {
                     $('.lnb ul li ul li').removeClass('on');
                     
                     $this.parent().siblings().removeClass('on');                    
                     
                     $this.parent('li').siblings('li').find('ul').slideUp();
                     $this.parent('li').find('ul ul').slideUp();
                     
                     if($depthTarget.css('display') === 'none') {
                         $depthTarget.slideDown();
                         $this.parent('li').addClass('on');
                     } else {
                         $depthTarget.slideUp();
                         $this.parent('li').removeClass('on');
                     }
                 } else {
                     //return false;
                  
                 }
                 //return false;
             });
         }
     }
     lnbUI.clickE('.lnb li')

    /* section servicelist */
    $("section>div.sec1>div.faq>ul>li").mouseover(function(e){
        $(this).css({"background-color":"rgba(68,68,68,1)"});
    });
    $("section>div.sec1>div.faq>ul>li").mouseleave(function(e){
        $(this).css({"background-color":"rgba(0,0,0,0.3)"});
    });

    /*---------------------------커피머신--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.brew>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.brew>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.brew>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain1").css({"display":"none"});
        $("section > div.sec2 > div.bom1").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.brew>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.brew>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.brew>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom1").css({"display":"none"});
        $("section > div.sec2 > div.explain1").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain1 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

    /*---------------------------레인지--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.range>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.range>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.range>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain2").css({"display":"none"});
        $("section > div.sec2 > div.bom2").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.range>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.range>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.range>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom2").css({"display":"none"});
        $("section > div.sec2 > div.explain2").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain2 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

    /*---------------------------토스터--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.toaster>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.toaster>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.toaster>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain3").css({"display":"none"});
        $("section > div.sec2 > div.bom3").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.toaster>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.toaster>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.toaster>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom3").css({"display":"none"});
        $("section > div.sec2 > div.explain3").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain3 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

    /*---------------------------팟--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.pot>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.pot>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.pot>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain4").css({"display":"none"});
        $("section > div.sec2 > div.bom4").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.pot>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.pot>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.pot>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom4").css({"display":"none"});
        $("section > div.sec2 > div.explain4").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain4 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

    /*---------------------------랜턴--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.lantern>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.lantern>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.lantern>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain5").css({"display":"none"});
        $("section > div.sec2 > div.bom5").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.lantern>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.lantern>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.lantern>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom5").css({"display":"none"});
        $("section > div.sec2 > div.explain5").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain5 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

    /*---------------------------라이트--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.light>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.light>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.light>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain6").css({"display":"none"});
        $("section > div.sec2 > div.bom6").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.light>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.light>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.light>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom6").css({"display":"none"});
        $("section > div.sec2 > div.explain6").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain6 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

    /*---------------------------스피커--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.speaker>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.speaker>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.speaker>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain7").css({"display":"none"});
        $("section > div.sec2 > div.bom7").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.speaker>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.speaker>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.speaker>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom7").css({"display":"none"});
        $("section > div.sec2 > div.explain7").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain7 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

    /*---------------------------클리너--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.cleaner>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.cleaner>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.cleaner>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain8").css({"display":"none"});
        $("section > div.sec2 > div.bom8").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.cleaner>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.cleaner>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.cleaner>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom8").css({"display":"none"});
        $("section > div.sec2 > div.explain8").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain8 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

    /*---------------------------퓨어--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.pure>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.pure>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.pure>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain9").css({"display":"none"});
        $("section > div.sec2 > div.bom9").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.pure>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.pure>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.pure>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom9").css({"display":"none"});
        $("section > div.sec2 > div.explain9").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain9 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

    /*---------------------------에어--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.air>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.air>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.air>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain10").css({"display":"none"});
        $("section > div.sec2 > div.bom10").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.air>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.air>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.air>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom10").css({"display":"none"});
        $("section > div.sec2 > div.explain10").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain10 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

    /*---------------------------흄--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.hum>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.hum>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.hum>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain11").css({"display":"none"});
        $("section > div.sec2 > div.bom11").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.hum>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.hum>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.hum>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom11").css({"display":"none"});
        $("section > div.sec2 > div.explain11").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain11 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

/*---------------------------팬--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.fan>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.fan>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.fan>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain12").css({"display":"none"});
        $("section > div.sec2 > div.bom12").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.fan>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.fan>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.fan>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom12").css({"display":"none"});
        $("section > div.sec2 > div.explain12").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain12 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

/*---------------------------그린팬--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.green>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.green>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.green>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain13").css({"display":"none"});
        $("section > div.sec2 > div.bom13").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.green>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.green>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.green>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom13").css({"display":"none"});
        $("section > div.sec2 > div.explain13").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain13 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });

/*---------------------------그린팬--------------------------*/
    /* 제품사양 */
    $("div.sec2>div.dock>ul.products>li.list_1>ul.products_list>li:eq(2) a").click(function(){
        $("div.sec2>div.dock>ul.products>li.list_1>ul.products_list>li").removeClass("more, more2");
        $("div.sec2>div.dock>ul.products>li.list_1>ul.products_list>li").eq(2).toggleClass("more");
        $("section > div.sec2 > div.explain14").css({"display":"none"});
        $("section > div.sec2 > div.bom14").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 */
    $("div.sec2>div.dock>ul.products>li.list_1>ul.products_list>li:eq(4) a").click(function(){
        $("div.sec2>div.dock>ul.products>li.list_1>ul.products_list>li:eq(2)").removeClass("more");
        $("div.sec2>div.dock>ul.products>li.list_1>ul.products_list>li").eq(4).toggleClass("more2");
        $("section > div.sec2 > div.bom14").css({"display":"none"});
        $("section > div.sec2 > div.explain14").toggle({"display":"block"});
        return false;
    });

    /* 자주하는 질문 클릭 후 답변 */
    $("section > div.sec2 > div.explain14 > div.explainwrap > dl > dt").click(function(e){
        e.preventDefault()
        $(this).next().toggle({"display":"block"}, 200);
    });
});