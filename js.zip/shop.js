$(function(){
    /* --------------- 드롭다운 --------------- */
    $(".products_menu").hover(
        function(){                                
            $(".products_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".products_menu .dropdown").removeClass("over");
        },        
    );    
    $(".about_menu").hover(
        function(){                                
            $(".about_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".about_menu .dropdown").removeClass("over");
        }
    );  
    $(".support_menu").hover(
        function(){                                
            $(".support_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".support_menu .dropdown").removeClass("over");
        }
    );   
    $(".news_menu").hover(
        function(){                                
            $(".news_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".news_menu .dropdown").removeClass("over");
        }
    );  
    
    /* --------------- 드롭다운 글자색 hover --------------- */  
    $(".left_menu > li").hover(
        function(){        
            $(this).addClass("on")        
        },
        function(){        
            $(".left_menu > li").removeClass("on")        
        }
    );  
    
    $(".dropdown .products").hover(
        function(){        
            $(".products_menu").addClass("on")        
        },
        function(){        
            $(".products_menu").removeClass("on")        
        }
    );    
    $(".dropdown .about").hover(
        function(){        
            $(".about_menu a").addClass("on")        
        },
        function(){        
            $(".about_menu a").removeClass("on")        
        }
    );
    $(".dropdown .support").hover(
        function(){        
            $(".support_menu a").addClass("on")        
        },
        function(){        
            $(".support_menu a").removeClass("on")        
        }
    );
    $(".dropdown .news").hover(
        function(){        
            $(".news_menu a").addClass("on")        
        },
        function(){        
            $(".news_menu a").removeClass("on")        
        }
    );

     /* --------------- 모바일 메뉴 --------------- */
    
     mobile_menu();
    
     function mobile_menu(){
         var $menu = null;
         var $left_gnb = null;
 
         function start(){
             init();
             init_event();
         }
 
         function init(){
             $menu = $('.menu');
             $left_gnb = $('.left_gnbWrap');
         }
         function init_event(){            
             $menu.click(function(e){
                 e.preventDefault();
                 $left_gnb.addClass('on');
             });            
           
             $('.close').click(function(e){
                 e.preventDefault();    
                 $left_gnb.removeClass('on');   
             }); 
             
             $(window).resize(function(){
                 $left_gnb.removeClass('on');
             });
         }
         start(); 
     }
 
     var lnbUI = {
         clickE: function(target) {
             var $target = $(target);
             
             $(target).each(function() {
                if($(this).find('> ul').length > 0) {
                    return true;
                }
                 $(this).addClass('noDepth');
             });
             
             $target.on('click', 'a', function() {
                 var $this = $(this);
                 var $depthTarget = $this.next();
                 var $siblings = $this.parent().siblings(); 
                 
                 if($this.parent('li').hasClass('noDepth') === false) {
                     $('.lnb ul li ul li').removeClass('on');
                     
                     $this.parent().siblings().removeClass('on');                    
                     
                     $this.parent('li').siblings('li').find('ul').slideUp();
                     $this.parent('li').find('ul ul').slideUp();
                     
                     if($depthTarget.css('display') === 'none') {
                         $depthTarget.slideDown();
                         $this.parent('li').addClass('on');
                     } else {
                         $depthTarget.slideUp();
                         $this.parent('li').removeClass('on');
                     }
                 } else {
                     //return false;
                  
                 }
                 //return false;
             });
         }
     }
     lnbUI.clickE('.lnb li')

    /* section servicelist */
    $('.shop_nav ul li a').click(function(){
        $(this).addClass('shop_nav_on');
        $('.shop_nav ul li a').not(this).removeClass('shop_nav_on');
        return false;
    });
    $('.shop_nav ul li a:eq(0)').click(function(){
        $('.shop_product div').css({'display':'none'});
        $('.shop_product .shop_cleaner').css({'display':'block'});
        return false;
    });
    $('.shop_nav ul li a:eq(1)').click(function(){
        $('.shop_product div').css({'display':'none'});
        $('.shop_product .shop_audio').css({'display':'block'});
        return false;
    });
    $('.shop_nav ul li a:eq(2)').click(function(){
        $('.shop_product div').css({'display':'none'});
        $('.shop_product .shop_air').css({'display':'block'});
        return false;
    });
    $('.shop_nav ul li a:eq(3)').click(function(){
        $('.shop_product div').css({'display':'none'});
        $('.shop_product .shop_kitchen').css({'display':'block'});
        return false;
    });
    $('.shop_nav ul li a:eq(4)').click(function(){
        $('.shop_product div').css({'display':'none'});
        $('.shop_product .shop_lighting').css({'display':'block'});
        return false;
    });
    $('.shop_nav ul li a:eq(5)').click(function(){
        $('.shop_product div').css({'display':'none'});
        $('.shop_product .shop_filter').css({'display':'block'});
        return false;
    });
    $('.shop_nav ul li a:eq(6)').click(function(){
        $('.shop_product div').css({'display':'none'});
        $('.shop_product .shop_accessory').css({'display':'block'});
        return false;
    });
});