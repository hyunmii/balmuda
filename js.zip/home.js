$(document).ready(function(){
    /* --------------- 드롭다운 --------------- */
    $(".products_menu").hover(
        function(){                                
            $(".products_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".products_menu .dropdown").removeClass("over");
        },        
    );    
    $(".about_menu").hover(
        function(){                                
            $(".about_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".about_menu .dropdown").removeClass("over");
        }
    );  
    $(".support_menu").hover(
        function(){                                
            $(".support_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".support_menu .dropdown").removeClass("over");
        }
    );   
    $(".news_menu").hover(
        function(){                                
            $(".news_menu .dropdown").addClass("over");                
        },
        function(){                
            $(".news_menu .dropdown").removeClass("over");
        }
    );  

    /* --------------- 드롭다운 글자색 hover --------------- */  
    $(".left_menu > li").hover(
        function(){        
            $(this).addClass("on")        
        },
        function(){        
            $(".left_menu > li").removeClass("on")        
        }
    );  

    $(".dropdown .products").hover(
        function(){        
            $(".products_menu").addClass("on")        
        },
        function(){        
            $(".products_menu").removeClass("on")        
        }
    );    
    $(".dropdown .about").hover(
        function(){        
            $(".about_menu a").addClass("on")        
        },
        function(){        
            $(".about_menu a").removeClass("on")        
        }
    );
    $(".dropdown .support").hover(
        function(){        
            $(".support_menu a").addClass("on")        
        },
        function(){        
            $(".support_menu a").removeClass("on")        
        }
    );
    $(".dropdown .news").hover(
        function(){        
            $(".news_menu a").addClass("on")        
        },
        function(){        
            $(".news_menu a").removeClass("on")        
        }
    );
});

/*----------------메인 슬라이드 배너---------------*/
$(document).ready(function(){
    
    var $slides=$(".bxslider"); 
    var slider=$slides.bxSlider({
       pager: true,
       controls: false,
       infiniteLoop: true,
         auto: true
    });

    $('.banner_prev').on("click", function(){
        slider.goToPrevSlide();
     });
     $('.banner_next').on("click", function(){
        slider.goToNextSlide();
     });
});
$(document).on('click','.baaner_prev,.banner_next,.bx-pager',function() {
    slider.stopAuto();
    slider.startAuto();
});

/* --------------- 모바일 메뉴 --------------- */
$(function(){
mobile_menu();
    
function mobile_menu(){
    var $menu = null;
    var $left_gnb = null;

    function start(){
        init();
        init_event();
    }

    function init(){
        $menu = $('.menu');
        $left_gnb = $('.left_gnbWrap');
    }
    function init_event(){            
        $menu.click(function(e){
            e.preventDefault();
            $left_gnb.addClass('on');
        });            
      
        $('.close').click(function(e){
            e.preventDefault();    
            $left_gnb.removeClass('on');   
        }); 
        
        $(window).resize(function(){
            $left_gnb.removeClass('on');
        });
    }
    start(); 
}

var lnbUI = {
    clickE: function(target) {
        var $target = $(target);
        
        $(target).each(function() {
           if($(this).find('> ul').length > 0) {
               return true;
           }
            $(this).addClass('noDepth');
        });
        
        $target.on('click', 'a', function() {
            var $this = $(this);
            var $depthTarget = $this.next();
            var $siblings = $this.parent().siblings(); 
            
            if($this.parent('li').hasClass('noDepth') === false) {
                $('.lnb ul li ul li').removeClass('on');
                
                $this.parent().siblings().removeClass('on');                    
                
                $this.parent('li').siblings('li').find('ul').slideUp();
                $this.parent('li').find('ul ul').slideUp();
                
                if($depthTarget.css('display') === 'none') {
                    $depthTarget.slideDown();
                    $this.parent('li').addClass('on');
                } else {
                    $depthTarget.slideUp();
                    $this.parent('li').removeClass('on');
                }
            } else {
                //return false;
             
            }
            //return false;
        });
    }
}
lnbUI.clickE('.lnb li')
});



/*-------------------레시피 슬라이드------------------*/
/*-------------------이미지슬라이드-------------------*/
$(function(){
    var $prevBtn=$("p.recipe_prev");
    var $nextBtn=$("p.recipe_next");
    var $slides=$(".recipe_slides");
 
 
    var slider=$slides.bxSlider({
       minSlides: 1,
       maxSlides: 3,
       slideWidth: 520,
       slideHeight: 520,
       slideMargin: 30,
       infiniteLoop: true,
       moveSlides: 1,
       pager: false,
       controls: false,
         auto: true,
         shrinkItems:true
    });
    
    $prevBtn.on("click", function(){
       slider.goToPrevSlide();
    });
    $nextBtn.on("click", function(){
       slider.goToNextSlide();
    });
 
    // 키보드
    $(".recipe_bannerZone").focusin(function(){
       
       $(this).find("button").bind({ 
          "keydown": function(e){
             var classname=$(this).attr("class");
             var keycode=e.keyCode;
             
             if(classname == "prevBtn" && keycode == 37){ 
                slider.goToPrevSlide();
             }else if(classname == "nextBtn" && keycode == 39){ 
                slider.goToNextSlide();
             }
          }
       });
    });
    $("recipe_bannerZone").focusout(function(){
       console.log("focusout");
       $(this).find("button").unbind("keydown");
    });
 
    $(".recipe_bannerZone").append("\r\n", $prevBtn, "\n\r", $nextBtn);
    
 });
/*--------------------텍스트--------------------------*/
$(function(){
	var n=0;
	$('ul.recipe_text_list li').eq(0).addClass('recipe_on');


	setInterval(function(){
		if(n < 2){
			n=n+1;//n++;
		}
		else{
			n=0;
		}
		$('ul.recipe_text_list li').removeClass('recipe_on');
		$('ul.recipe_text_list li').eq(n).addClass('recipe_on');
	},4000);
});
    
       
/*-------------------스크롤 이벤트--------------------*/

$(document).ready(function() {
    $(window).scroll( function(){
			
        $('.area').each( function(i){
            
            var bottom_of_element = $(this).offset().top + $(this).outerHeight() / 3;
            var bottom_of_window = $(window).scrollTop() + $(window).height();
            
            if( bottom_of_window > bottom_of_element ){
                $(this).animate({'opacity':'1','margin-top':'100px'},500);
            }
            
        }); 
    });
});




    /* --------------갤러리 슬라이드 배너---------------*/
    $(function(){
        
        var $prevBtn=$("p.prev");
        var $nextBtn=$("p.next");
        var $slides=$(".slides");
     
     
        
        
        $prevBtn.on("click", function(){
           $slider.goToPrevSlide();
        });
        $nextBtn.on("click", function(){
           $slider.goToNextSlide();
        });
     
        // 키보드
        $(".bannerZone").focusin(function(){
           
           $(this).find("button").bind({ 
              "keydown": function(e){
                 var classname=$(this).attr("class");
                 var keycode=e.keyCode;
                 
                 if(classname == "prevBtn" && keycode == 37){ 
                    slider.goToPrevSlide();
                 }else if(classname == "nextBtn" && keycode == 39){ 
                    slider.goToNextSlide();
                 }
              }
           });
        });
        $("bannerZone").focusout(function(){
           console.log("focusout");
           $(this).find("button").unbind("keydown");
        });
     
        $(".bannerZone").append("\r\n", $prevBtn, "\n\r", $nextBtn);

        
        var $slider; 
        function buildSliderConfiguration() { 
            
            var deviceWidth = $(window).width(); 
            
             
            var slideNum; 
            var slideMargin; 
               
            if (deviceWidth < 500) { 
                slideNum = 1; 
                slideMargin = 10; 
            } else if (deviceWidth < 800) { 
                slideNum = 2; 
                slideMargin = 10; 
            } else { 
                slideNum = 3; 
                slideMargin = 30; 
             
            }
            
            return { 
                minSlides: slideNum,
                maxSlides: slideNum,
                slideWidth: 400,
                slideHeight: 400,
                slideMargin: 10,
                infiniteLoop: true,
                moveSlides: 1,
                pager: false,
                controls: false,
                  auto: true,
                  shrinkItems:true
                 }; 
                } 
                function configureSlider() { 
                    var config = buildSliderConfiguration(); 
                    
                    if ($slider && $slider.reloadSlider) { 
                        $slider.reloadSlider(config); 
                    } else { 
                        $slider = $('.slides').bxSlider(config);  
                     } 
                    } 
                     
                        $(window).on("orientationchange resize", configureSlider); configureSlider();


     });
     



     